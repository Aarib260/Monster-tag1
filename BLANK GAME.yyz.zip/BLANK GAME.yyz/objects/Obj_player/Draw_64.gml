var bar_x = 20;
var bar_y = 20;
var bar_width = 200;
var bar_height = 20;

// Background (red)
draw_set_color(c_red);
draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, false);

// Health amount (green)
draw_set_color(c_green);
var health_width = (hp / max_hp) * bar_width;

draw_rectangle(bar_x, bar_y, bar_x + health_width, bar_y + bar_height, false);
draw_set_color(c_white);
draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, true);
draw_set_color(c_white);
draw_text(bar_x, bar_y - 18, "HP: " + string(hp));