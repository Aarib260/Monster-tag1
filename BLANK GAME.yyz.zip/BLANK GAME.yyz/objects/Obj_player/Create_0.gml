move_speed = 4;
jump_speed = 16;

move_x = 0;
move_y = 0;

max_hp = 100;
hp = 100;
invincible = false;
inv_timer = 0;