move_x = keyboard_check(vk_right) - keyboard_check(vk_left)
move_x = move_x * move_speed

if place_meeting(x, y+2, Obj_ground)
{
	move_y = 0;
	
	if keyboard_check(vk_space) move_y = -jump_speed;
}
else if move_y < 10
{
	move_y += 1;
}

move_and_collide(move_x, move_y, Obj_ground);

if move_x != 0
{
	image_xscale = sign(move_x);
}



if (place_meeting(x, y, Obj_spikes) && !invincible)
{
    hp -= 25;
    invincible = true;
    inv_timer = 30;
}

if (invincible)
{
    inv_timer -= 1;
    
    if (inv_timer <= 0)
    {
        invincible = false;
    }
}

if (hp <= 0)
{
    room_restart();
}
