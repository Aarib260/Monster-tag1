room_restart();
///restarts everything in the room so you might wanna change it too teleport player
//to orignal position